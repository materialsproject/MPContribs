"""
Type annotations for aioboto3.session module.

Copyright 2026 Vlad Emelianov
"""

import sys
from types import TracebackType
from typing import Any, Generic, TypeVar, overload

from aioboto3.resources.base import AIOBoto3ServiceResource
from aioboto3.resources.factory import AIOBoto3ResourceFactory
from aiobotocore.config import AioConfig
from aiobotocore.credentials import AioCredentials
from aiobotocore.session import AioSession as AioBotocoreSession
from aiobotocore.session import ClientCreatorContext
from boto3.session import Session as Boto3Session
from botocore.loaders import Loader
from types_aiobotocore_s3.client import S3Client
from types_aiobotocore_s3.service_resource import S3ServiceResource
from types_aiobotocore_sqs.client import SQSClient
from types_aiobotocore_sqs.service_resource import SQSServiceResource

if sys.version_info >= (3, 12):
    from typing import Literal
else:
    from typing_extensions import Literal

class Session(Boto3Session):
    def __init__(
        self,
        aws_access_key_id: str | None = ...,
        aws_secret_access_key: str | None = ...,
        aws_session_token: str | None = ...,
        region_name: str | None = ...,
        botocore_session: AioBotocoreSession | None = ...,
        profile_name: str | None = ...,
        aws_account_id: str | None = ...,
    ) -> None:
        self._session: AioBotocoreSession  # type: ignore[override]
        self.resource_factory: AIOBoto3ResourceFactory  # type: ignore[override]
        self._loader: Loader
    async def get_credentials(self) -> AioCredentials | None: ...  # type: ignore[override]
    async def get_available_regions(  # type: ignore[override]
        self,
        service_name: str,
        partition_name: str = ...,
        allow_non_regional: bool = ...,
    ) -> list[str]: ...
    @overload  # type: ignore[override]
    def client(  # type: ignore[override]
        self,
        service_name: Literal["s3"],
        region_name: str | None = ...,
        api_version: str | None = ...,
        use_ssl: bool | None = ...,
        verify: bool | str | None = ...,
        endpoint_url: str | None = ...,
        aws_access_key_id: str | None = ...,
        aws_secret_access_key: str | None = ...,
        aws_session_token: str | None = ...,
        config: AioConfig | None = ...,
        aws_account_id: str | None = ...,
    ) -> ClientCreatorContext[S3Client]:
        """
        Create client for S3 service.
        """

    @overload  # type: ignore[override]
    def client(  # type: ignore[override]
        self,
        service_name: Literal["sqs"],
        region_name: str | None = ...,
        api_version: str | None = ...,
        use_ssl: bool | None = ...,
        verify: bool | str | None = ...,
        endpoint_url: str | None = ...,
        aws_access_key_id: str | None = ...,
        aws_secret_access_key: str | None = ...,
        aws_session_token: str | None = ...,
        config: AioConfig | None = ...,
        aws_account_id: str | None = ...,
    ) -> ClientCreatorContext[SQSClient]:
        """
        Create client for SQS service.
        """

    @overload  # type: ignore[override]
    def resource(  # type: ignore[override]
        self,
        service_name: Literal["s3"],
        region_name: str | None = ...,
        api_version: str | None = ...,
        use_ssl: bool | None = ...,
        verify: bool | str | None = ...,
        endpoint_url: str | None = ...,
        aws_access_key_id: str | None = ...,
        aws_secret_access_key: str | None = ...,
        aws_session_token: str | None = ...,
        config: AioConfig | None = ...,
        aws_account_id: str | None = ...,
    ) -> ResourceCreatorContext[S3ServiceResource]:
        """
        Create ServiceResource for S3 service.
        """

    @overload  # type: ignore[override]
    def resource(  # type: ignore[override]
        self,
        service_name: Literal["sqs"],
        region_name: str | None = ...,
        api_version: str | None = ...,
        use_ssl: bool | None = ...,
        verify: bool | str | None = ...,
        endpoint_url: str | None = ...,
        aws_access_key_id: str | None = ...,
        aws_secret_access_key: str | None = ...,
        aws_session_token: str | None = ...,
        config: AioConfig | None = ...,
        aws_account_id: str | None = ...,
    ) -> ResourceCreatorContext[SQSServiceResource]:
        """
        Create ServiceResource for SQS service.
        """

_AIOBoto3ServiceResource = TypeVar("_AIOBoto3ServiceResource", bound=AIOBoto3ServiceResource)

class ResourceCreatorContext(Generic[_AIOBoto3ServiceResource]):
    def __init__(
        self,
        session: Session,
        service_name: str,
        region_name: str,
        api_version: str,
        use_ssl: bool,
        verify: bool,
        endpoint_url: str,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        aws_session_token: str,
        config: AioConfig,
        resource_model: Any,
    ) -> None: ...
    async def __aenter__(self) -> _AIOBoto3ServiceResource: ...
    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None: ...
